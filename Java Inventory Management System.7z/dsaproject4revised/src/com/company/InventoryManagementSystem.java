package com.company;

// The main method to run the application
public class InventoryManagementSystem {

    public static void main(String[] args) {
        // Getting the singleton instance of the controller
        InventoryController controller = InventoryController.getInstance();
    }
}